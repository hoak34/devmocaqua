			</div><!-- .uk-grid -->
		</div><!-- .uk-container -->
	</div><!-- #content -->

	<footer id="colophon" class="site-footer footer-main" role="contentinfo">


<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- mcq1 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4228803500473176"
     data-ad-slot="8975149244"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
<!-- Histats.com  START  (standard)--><div style="position:fixed; right:0; bottom:0px">
<script type="text/javascript">document.write(unescape("%3Cscript src=%27http://s10.histats.com/js15.js%27 type=%27text/javascript%27%3E%3C/script%3E"));</script>
<a href="http://www.histats.com" target="_blank" title="free counter statistics" ><script  type="text/javascript" >
try {Histats.start(1,3178845,4,428,112,75,"00011011");
Histats.track_hits();} catch(err){};
</script></a>
<noscript><a href="http://www.histats.com" target="_blank"><img  src="http://sstatic1.histats.com/0.gif?3178845&101" alt="free counter statistics" border="0"></a></noscript>
</div><!-- Histats.com  END  -->
		
		<div class="footer-top">
			<div class="uk-container uk-container-center">
				<div class="uk-grid" data-uk-grid-match>
					
					<div class="uk-width-1-1 uk-width-small-2-4 uk-width-medium-1-4">
						<?php dynamic_sidebar( 'footer-1' ); ?>
					</div>

					<div class="uk-width-1-1 uk-width-small-2-4 uk-width-medium-1-4">
						<?php dynamic_sidebar( 'footer-2' ); ?>
					</div>

					<div class="uk-width-1-1 uk-width-small-2-4 uk-width-medium-1-4">
						<?php dynamic_sidebar( 'footer-3' ); ?>
					</div>

					<div class="uk-width-1-1 uk-width-small-2-4 uk-width-medium-1-4">
						<?php dynamic_sidebar( 'footer-4' ); ?>
					</div>

				</div>
			</div>
		</div>

		<div class="footer-bottom">
			<div class="uk-container uk-container-center">

				<div class="footer-bottom-left">
					<p>Copyright © 2016 Mộc Aqua. Mộc Aqua - 665 Hoàng Hoa Thám - Ba Đình - Hà Nội | Hotline: 090.341.1987 - 0966.302.302.</p>
				</div>

				<div class="footer-bottom-right">
				 	<?php aquamag_social_links(); ?>
				</div>
			
			</div>
		</div>

	</footer><!-- #colophon -->
	
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>